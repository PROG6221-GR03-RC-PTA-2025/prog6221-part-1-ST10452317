﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace POE_PART_1
{
    internal class Chatbot
    {
        public string name { get; set; } = "ChatBot";
        public DateTime startTime { get; set; } = DateTime.Now;
        Random random = new Random();
        string CurrentTopic = "";
        private ArrayList RecallArray = new ArrayList();
        public Dictionary<string, string> BotResponses = new Dictionary<string, string>

            //dictionary questions and answers
        {
            { "purpose", "My purpose is to keep you safe online" },
            { "what can i ask you about", "You can ask me about cybersecurity, password safety, phishing, scam, privacy and how to browse safely." },
            { "password safety", "The use of strong, unique credentials combined with proper management techniques to protect digital accounts from unauthorised access.\n\nWould you like to know more details about password safety?\n" },
            { "phishing", "Phishing is a cyber attack where attackers trick you into providing personal information. Always verify email sources before clicking links.\n\nWould you like to know more details about phishing?\n" },
            { "scam", "A scam is a dishonest scheme or fraud to trick individuals into giving away money or personal information.\n\nWould you like to know more details about scam?\n" },
            { "privacy", "Privacy refers to your ability to control what personal information you share online and who has access to it.\n\nWould you like to know more details about privacy?\n" },
            { "safe browsing", "Keep your browser updated, use HTTPS websites, and avoid clicking on suspicious links.\n\nWould you like to know more details about safe browsing?\n" },
            { "thanks", "You're welcome! have a good day"},
        };

        //phishing tips
        private List<string> phishingTips = new List<string> 
        {  
           "Below are tips for phishing: ",
           "Be cautious of emails asking for personal information.",
           "Never click suspicious links from unknown senders.",
           "Check for grammatical errors in emails-it could be phishing.",
           "Always verify the sender's address before replying." 
        };

        //password safety tips
        private List<string> passwordSafetyTips = new List<string>
        { 
           "Below are tips for password safety: ",
           "Use strong password with at least 12 characters, including uppercase, lowercase, numbers, and symbols.",
           "Avoid using personal information like names, birthdays, or ID numbers in your passwords.",
           "Never reuse passwords across multiple platforms or accounts.",
           "Enable two-factor authontication (2A) wherever possible for added security." 
        };
        
        //safe browsing tips
        private List<string> safeBrowsingTips = new List<string>
        {
           "Below are tips for safe browsing: ",
           "Always check that the website URL begins with 'https://' before entering sensitive information.",
           "Avoid clicking on suspicious links received via email, SMS, or social media.",
           "Keep your browser and antivirus software updated to defend against the latest threats.",
           "Only download software or apps from trusted sources or official websites."
        };

        //scam tips
        private List<string> scamTips = new List<string>
        {
            "Below are tips for scam: ",
            "Be wary of offers that seem to good to be true - they usually are!",
            "Scammers often create a false sense of urgency. Take your time to verify before taking action.",
            "Never share personal information with someone who contacts you unexpected, even if they claim to be from a trusted organization."
        };
   
        //privacy tips
        private List<string> privacyTips = new List<string>
        {
          "Below are tips for pivacy: ",
          "Regularly review and update your privacy settings on social media accounts.", 
          "Be mindful of what personal information you share online - once it's out there, it's hard to take back.",
          "Consider using VPNs when connecting to public Wi-Fi networks to protect your data."
        };

        //get responses
        public string getResponse(string userInput, User newUser)
        {
            userInput = userInput.ToLower();
           
            if (userInput.Contains("hello")) 
            {
                return "hello " + newUser.name + ", How can i assist you today?";
            }
            else if (userInput.Contains("how are you"))
            {
                return "i'm just a bot, but i'm doing great! how about you?";
            }
            else if (userInput.Contains("good") || userInput.Contains("fine") || userInput.Contains("great") || userInput.Contains("okay"))
            {
                return "That's good, how can i assist you today?";
            }
            else if (userInput.Contains("phishing") && userInput.Contains("tip"))
            {
                int Pos = random.Next(0, phishingTips.Count);
                return phishingTips[Pos];
            }
            else if (userInput.Contains("password safety") && userInput.Contains("tip"))
            {
                int Pos = random.Next(0, passwordSafetyTips.Count);
                return passwordSafetyTips[Pos];
            }
            else if (userInput.Contains("safe browsing") && userInput.Contains("tip"))
            {
                int Pos = random.Next(0, safeBrowsingTips.Count);
                return safeBrowsingTips[Pos];
            }
            else if (userInput.Contains("worried") || userInput.Contains("frustrated") || userInput.Contains("curious")
                && userInput.Contains("phishing"))
            {
                return "It's completely understandable to feel that way about phishing. These scams can be tricky and deceptive." +
                    "Let me give you a few key tips to help you avoid getting caught.";
            }
            else if (userInput.Contains("worried") || userInput.Contains("frustrated") || userInput.Contains("curious")
                && userInput.Contains("password safety"))
            {
                return "You're not alone in feeling unsure about password safety." +
                    "Let me give you some important tips to help you secure your accounts.";
            }
            else if (userInput.Contains("worried") || userInput.Contains("frustrated") || userInput.Contains("curious")
                && userInput.Contains("safe browsing"))
            {
                return "It's great that you're being cautious while browsing." +
                    "Here are some safe browsing practices to keep you protected online. ";
            }
            else if (userInput.Contains("worried") || userInput.Contains("frustrated") || userInput.Contains("curious")
                && userInput.Contains("scam"))
            {
                return "It's completely underdtandable to feel uneasy about scams. Criminals are constantly finding ways to trick people." +
                    "Let me share a few useful tips to help you spot and avoid scams.";
            }
            else if (userInput.Contains("worried") || userInput.Contains("frustrated") || userInput.Contains("curious")
                && userInput.Contains("privacy"))
            {
                return "Many people are concerned about their online privacy, and for good reason." +
                    "Here are a few suggestions that can help you protect your personal data.";
            }
            else if (userInput.Contains("confused"))
            {
                return "Would you like to know more details about " + CurrentTopic + "?";
            }
            else if (userInput.Contains("yes"))
            {
                string Tips = "";
                if (CurrentTopic.Equals("phishing"))
                {
                    for (int i = 0; i < phishingTips.Count; i++)
                    {
                        Tips += "\n" + phishingTips[i];
                    }
                }
             else if (CurrentTopic.Equals("safe browsing"))
                {
                    for (int i = 0; i < safeBrowsingTips.Count; i++)
                    {
                        Tips += "\n" + safeBrowsingTips[i];
                    }
                }
                else if (CurrentTopic.Equals("password safety"))
                {
                    for (int i = 0; i < passwordSafetyTips.Count; i++)
                    {
                        Tips += "\n" + passwordSafetyTips[i];
                    }
                }
                else if (CurrentTopic.Equals("scam"))
                {
                    for (int i = 0; i < scamTips.Count; i++)
                    {
                        Tips += "\n" + scamTips[i];
                    }
                }
                else if (CurrentTopic.Equals("privacy"))
                {
                    for (int i = 0; i < privacyTips.Count; i++)
                    {
                        Tips += "\n" + privacyTips[i];
                    }
                }
                return Tips;
            }
            else if (userInput.Contains("no"))
            {
                return "As someone interested in " + CurrentTopic + " you might also want to review cybersecurity topics like password safety, safe browsing, phishing, scam and privacy. ";
            }
            else if (userInput.Contains("interested"))
            {
                foreach (string word in BotResponses.Keys)
                {
                    if (userInput.Contains(word))
                    {
                        CurrentTopic= word;
                    }
                }
            if (CurrentTopic.Equals("phishing"))
                {
                  RecallArray.Add(CurrentTopic);
                    return "Great! i'll remeber that you're interested in " + CurrentTopic;
                }
                if (CurrentTopic.Equals("scam"))
                {
                    RecallArray.Add(CurrentTopic);
                    return "Great! i'll remeber that you're interested in " + CurrentTopic;
                }
                if (CurrentTopic.Equals("privacy"))
                {
                    RecallArray.Add(CurrentTopic);
                    return "Great! i'll remeber that you're interested in " + CurrentTopic;
                }
                if (CurrentTopic.Equals("safe browsing"))
                {
                    RecallArray.Add(CurrentTopic);
                    return "Great! i'll remeber that you're interested in " + CurrentTopic;
                }
                if (CurrentTopic.Equals("password safety"))
                {
                    RecallArray.Add(CurrentTopic);
                    return "Great! i'll remeber that you're interested in " + CurrentTopic;
                }
                return "I can only cover these Cybersecurity topics [Phishing, Scam, Privacy, Safe Browsing, Password Safety]";
            }
            else if (userInput.Contains("exit"))
            {
                string Archive = "";
                if (RecallArray.Count != 0)
                {
                    for (int i = 0; i < RecallArray.Count; i++)
                    {
                        if (RecallArray[i].Equals("phishing"))
                        {
                            Archive += "Since phishing caught your attention, be extra careful with emails that create preassure or ask for private info - they're often traps.";
                        }
                    else if (RecallArray[i].Equals("password safety"))
                        {
                            Archive += "Since you're focused on password safety, try not to reuse the same password on multiple sites - it's a common mistake.";
                        }
                    else if (RecallArray[i].Equals("safe browsing"))
                        {
                            Archive += "Because you're interested in safe browsing, remember to regularly clear your browser's cache and avoid downloading files from shady sites.";
                        }
                    else if (RecallArray[i].Equals("scam"))
                        {
                            Archive += "As someone curious about scams, keep in mind that urgency in message is often a red flag - always verify before acting.";
                        }
                    else if (RecallArray[i].Equals("privacy"))
                        {
                            Archive += "As someone interested in privacy, you might want to review the security settings on your accounts.";
                        }
                    }
                }
                return Archive + "\nexit";
            }
            //validating empty user Input
            else if (string.IsNullOrEmpty(userInput))
            {
              return ("input cannot be empty");
            }
            else
            {
                foreach (string word in BotResponses.Keys)
                {
                    if (userInput.Contains(word))
                    {
                        CurrentTopic = word;
                        return BotResponses[word];
                    }
                }
                return "could you please paraphrase";
            }
        }

    }
}
